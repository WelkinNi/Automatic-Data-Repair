package tuffy.util;

public class SuperMan {

}
