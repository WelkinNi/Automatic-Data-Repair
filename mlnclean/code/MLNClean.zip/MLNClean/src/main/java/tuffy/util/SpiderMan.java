package tuffy.util;

public class SpiderMan {

}
