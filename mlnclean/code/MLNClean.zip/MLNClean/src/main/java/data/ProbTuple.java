package data;

import java.util.List;

public class ProbTuple {
	
	public List<ProbAttribute> content = null;

}
