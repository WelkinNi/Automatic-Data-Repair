package data;

import java.util.ArrayList;
import java.util.List;

public class Conflicts {
	
	List<ConflictTuple> tuples = new ArrayList<ConflictTuple>();

	ArrayList<Integer> tupleIDs = new ArrayList<>();
}
