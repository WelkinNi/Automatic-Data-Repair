package data;

import java.util.ArrayList;

/**
 * Created by gcc on 17-8-22.
 */
public class MLNClause {
    public Integer[] atomids = null;
    public double weight = 0.0f;
    public ArrayList<String> values = new ArrayList<String>();
}
