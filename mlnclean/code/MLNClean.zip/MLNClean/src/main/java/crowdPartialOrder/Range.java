package crowdPartialOrder;

public class Range {
	public float up;
	public float down;
	
	public Range(float up, float down){
		this.up = up;
		this.down = down;
	}
}
