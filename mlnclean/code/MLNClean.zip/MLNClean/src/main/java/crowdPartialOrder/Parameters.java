package crowdPartialOrder;

public class Parameters {
	public static float threshold = 0.1f; 
	public static float tau = 0.7f;
	public static float minValue = 0.0001f;
	public static final int Anum = 4; //attribute number
}
